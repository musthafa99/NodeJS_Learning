var first="blue";
var second="green"

console.log("Before Swapping");
console.log(first);
console.log(second);

let third=first;
first=second;
second=third;

console.log("After Swapping");
console.log(first);
console.log(second);
