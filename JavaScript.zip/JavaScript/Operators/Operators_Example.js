let a=15;
let b=10;

//Arthimatic Operations.
console.log(a+b);
console.log(a-b);
console.log(a*b);
console.log(a/b);
console.log(a%b);
console.log(a**b);

//Equality Operators
let c=10;
let d='10'
console.log(c===d);
console.log(c==d);

// Terniary Operator

let x=10;
let y=x<20 ? 'true' : 'false'
console.log(y);

//Logical AND Operator
console.log(true && true);

