let number = max(60, 140);
console.log(number);

function max(a, b) {
  return (a > b) ? a : b;
}