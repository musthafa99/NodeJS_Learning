//  var hour=20;

// if(hour >=6 && hour <=12)
// {
//     console.log("Good Morning")
// }
// else if(hour >=12 && hour <=18)
// {
//     console.log("Good Afternoon")
// }
// else
// {
//     console.log("Good Night") 
// }

// var role="Customer";

// switch(role){
//     case 'Customer':
//         console.log("Role is customer");
//         break;
//     case 'Delivery':
//             console.log("Role is Delivery");
//             break;
//     default:
//         console.log("Unknown role");
// }

// for(var number=0;number<10;number++)
// {
//     if(number%2==0)
//         console.log(number);
// }

// var number=0;
// while(number<10)
// {
//     if(number%2!=0)
//         console.log(number);
//     number++;
// }

// var number=0;
// do
// {
//     if(number%3==0)
//         console.log(number);
//     number++;
    
// }while(number<10);

// break
for(var number=0;number<10;number++)
{
    
    if(number==7)
        break;
    console.log(number);
}

//continue
console.log("-----------");
for(var number=0;number<10;number++)
{
    
    if(number==7)
        continue;
    console.log(number);
}